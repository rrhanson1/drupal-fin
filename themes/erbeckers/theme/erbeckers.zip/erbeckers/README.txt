Requirements:
After setup your drupal 8 site. Download and enable(Don't set as default) this 
base theme https://www.drupal.org/project/mbase. 

After install "mbase" module, install the generated theme. You can change the
Home page content in theme settings page. 

Images are not part of GPL license, So you must not re-distribute the images for
Commercial purpose. All the template code are distributed under GPL license.
Image credits : 
  http://picjumbo.com/
  https://unsplash.com/grid

Help site is coming soon : help.cmsbots.com
You can hire us for premium support adal [at] cmsbots.com or for any other inquiry
  